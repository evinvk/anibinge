import { Router, type IRouter } from "express";
import {
  getTrendingAnime,
  getAiringAnime,
  getTopRatedAnime,
  getUpcomingAnime,
  getAnimeDetail,
} from "../lib/jikan";

const router: IRouter = Router();

router.get("/anime/trending", async (req, res): Promise<void> => {
  const page = parseInt(String(req.query.page ?? "1"), 10) || 1;
  try {
    const result = await getTrendingAnime(page);
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to fetch trending anime");
    res.status(502).json({ error: "Failed to fetch from upstream" });
  }
});

router.get("/anime/airing", async (req, res): Promise<void> => {
  const page = parseInt(String(req.query.page ?? "1"), 10) || 1;
  try {
    const result = await getAiringAnime(page);
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to fetch airing anime");
    res.status(502).json({ error: "Failed to fetch from upstream" });
  }
});

router.get("/anime/top-rated", async (req, res): Promise<void> => {
  const page = parseInt(String(req.query.page ?? "1"), 10) || 1;
  try {
    const result = await getTopRatedAnime(page);
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to fetch top-rated anime");
    res.status(502).json({ error: "Failed to fetch from upstream" });
  }
});

router.get("/anime/upcoming", async (req, res): Promise<void> => {
  const page = parseInt(String(req.query.page ?? "1"), 10) || 1;
  try {
    const result = await getUpcomingAnime(page);
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to fetch upcoming anime");
    res.status(502).json({ error: "Failed to fetch from upstream" });
  }
});

router.get("/anime/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw ?? "", 10);

  if (!id || isNaN(id)) {
    res.status(400).json({ error: "Invalid anime id" });
    return;
  }

  try {
    const result = await getAnimeDetail(id);
    res.json(result);
  } catch (err) {
    req.log.error({ err, id }, "Failed to fetch anime detail");
    res.status(502).json({ error: "Failed to fetch anime detail from upstream" });
  }
});

export default router;
