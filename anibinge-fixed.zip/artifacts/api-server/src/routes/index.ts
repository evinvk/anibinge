import { Router, type IRouter } from "express";
import healthRouter from "./health";
import scheduleRouter from "./schedule";
import animeRouter from "./anime";
import seasonalRouter from "./seasonal";
import searchRouter from "./search";

const router: IRouter = Router();

router.use(healthRouter);
router.use(scheduleRouter);
router.use(animeRouter);
router.use(seasonalRouter);
router.use(searchRouter);

export default router;
