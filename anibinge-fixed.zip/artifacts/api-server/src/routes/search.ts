import { Router, type IRouter } from "express";
import { searchAnime, getGenres } from "../lib/jikan";

const router: IRouter = Router();

router.get("/search", async (req, res): Promise<void> => {
  const q = String(req.query.q ?? "").trim();
  if (!q) {
    res.status(400).json({ error: "Query parameter 'q' is required" });
    return;
  }
  const page = parseInt(String(req.query.page ?? "1"), 10) || 1;
  const status = req.query.status ? String(req.query.status) : undefined;
  const genres = req.query.genres ? String(req.query.genres) : undefined;

  try {
    const result = await searchAnime(q, page, status, genres);
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Search failed");
    res.status(502).json({ error: "Search upstream failed" });
  }
});

router.get("/genres", async (req, res): Promise<void> => {
  try {
    const result = await getGenres();
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to fetch genres");
    res.status(502).json({ error: "Failed to fetch genres from upstream" });
  }
});

export default router;
