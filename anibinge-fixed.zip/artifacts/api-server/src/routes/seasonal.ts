import { Router, type IRouter } from "express";
import { getCurrentSeason } from "../lib/jikan";

const router: IRouter = Router();

router.get("/seasonal/current", async (req, res): Promise<void> => {
  const page = parseInt(String(req.query.page ?? "1"), 10) || 1;
  try {
    const result = await getCurrentSeason(page);
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to fetch current season");
    res.status(502).json({ error: "Failed to fetch from upstream" });
  }
});

export default router;
