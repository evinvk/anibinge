import { Router, type IRouter } from "express";
import { DAYS, getScheduleDay, getWeeklySchedule } from "../lib/jikan";

const router: IRouter = Router();

/**
 * GET /schedule/weekly
 * Returns the full 7-day airing schedule. Public — no auth required.
 */
router.get("/schedule/weekly", async (req, res): Promise<void> => {
  try {
    const weekly = await getWeeklySchedule();
    res.json(weekly);
  } catch (err) {
    req.log.error({ err }, "Failed to fetch weekly schedule");
    res.status(502).json({ error: "Failed to fetch schedule from upstream" });
  }
});

/**
 * GET /schedule/:day
 * Returns schedule for a specific day. Day must be lowercase day name.
 */
router.get("/schedule/:day", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.day) ? req.params.day[0] : req.params.day;
  const day = raw?.toLowerCase();

  if (!DAYS.includes(day as (typeof DAYS)[number])) {
    res.status(400).json({ error: `Invalid day. Valid days: ${DAYS.join(", ")}` });
    return;
  }

  try {
    const result = await getScheduleDay(day as (typeof DAYS)[number]);
    res.json({
      day,
      data: (result as { data: unknown[] }).data ?? [],
      total: ((result as { data: unknown[] }).data ?? []).length,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch day schedule");
    res.status(502).json({ error: "Failed to fetch schedule from upstream" });
  }
});

export default router;
