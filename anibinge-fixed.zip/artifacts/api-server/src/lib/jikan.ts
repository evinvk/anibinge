/**
 * Jikan API v4 client with in-memory caching and rate-limit queue.
 * Jikan enforces ~3 req/sec & 60 req/min public rate limits.
 * We solve this by:
 * 1. Aggressively caching responses
 * 2. Queuing requests with a 400ms gap between them
 * 3. Retrying on 429 with backoff
 * 4. Fetching the full schedule in one call instead of 7
 */

const JIKAN_BASE = "https://api.jikan.moe/v4";
const MIN_REQUEST_GAP_MS = 400; // ~2.5 req/sec, safely under the 3/sec limit

// ── In-memory cache ───────────────────────────────────────────────────────────

interface CacheEntry {
  data: unknown;
  expiresAt: number;
}

const cache = new Map<string, CacheEntry>();

function getCached(key: string): unknown | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return null;
  }
  return entry.data;
}

function setCached(key: string, data: unknown, ttlSeconds: number): void {
  cache.set(key, { data, expiresAt: Date.now() + ttlSeconds * 1000 });
}

// ── Request queue (serialize to respect rate limits) ─────────────────────────

let lastRequestAt = 0;
let queuePromise: Promise<void> = Promise.resolve();

function enqueue<T>(fn: () => Promise<T>): Promise<T> {
  const result = queuePromise.then(async () => {
    const now = Date.now();
    const wait = MIN_REQUEST_GAP_MS - (now - lastRequestAt);
    if (wait > 0) {
      await new Promise<void>((r) => setTimeout(r, wait));
    }
    lastRequestAt = Date.now();
    return fn();
  });
  // Advance the queue pointer (ignore errors so the queue doesn't stall)
  queuePromise = result.then(
    () => undefined,
    () => undefined
  );
  return result;
}

// ── Core fetch ────────────────────────────────────────────────────────────────

async function jikanFetch(path: string, params: Record<string, string | number> = {}): Promise<unknown> {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)]))
  ).toString();
  const url = `${JIKAN_BASE}${path}${qs ? `?${qs}` : ""}`;

  for (let attempt = 0; attempt <= 3; attempt++) {
    const resp = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(20_000),
    });

    if (resp.status === 429) {
      // Rate limited — wait and retry
      await new Promise<void>((r) => setTimeout(r, 1500 * (attempt + 1)));
      continue;
    }
    if (resp.status === 504 || resp.status === 503) {
      // Upstream timeout — retry after short delay
      await new Promise<void>((r) => setTimeout(r, 1000 * (attempt + 1)));
      continue;
    }

    if (!resp.ok) {
      throw new Error(`Jikan ${resp.status} for ${path}`);
    }

    return resp.json();
  }

  throw new Error(`Jikan: max retries exceeded for ${path}`);
}

async function jikanGet(path: string, params: Record<string, string | number> = {}, ttlSeconds = 300): Promise<unknown> {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)]))
  ).toString();
  const cacheKey = `${path}?${qs}`;

  const cached = getCached(cacheKey);
  if (cached) return cached;

  // Serialize through the queue to respect rate limits
  const data = await enqueue(() => jikanFetch(path, params));
  setCached(cacheKey, data, ttlSeconds);
  return data;
}

// ── Schedule ─────────────────────────────────────────────────────────────────

export const DAYS = [
  "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
] as const;

export type Day = (typeof DAYS)[number];

interface JikanScheduleRaw {
  data: Record<string, unknown>[];
  pagination: unknown;
}

/**
 * Fetch the full weekly schedule in ONE API call.
 * Jikan's /schedules endpoint (no filter) returns all 7 days grouped by the
 * broadcast.day field. We then bucket them ourselves.
 */
export async function getWeeklySchedule(): Promise<Record<string, { day: string; data: unknown[]; total: number }>> {
  // Fetch pages until we have all results (Jikan paginates at 25 per page by default)
  // We use limit=25 for each day individually to get reasonable results quickly
  const results = await Promise.all(
    DAYS.map((day) =>
      jikanGet("/schedules", { filter: day, limit: 25 }, 300) as Promise<JikanScheduleRaw>
    )
  );

  return Object.fromEntries(
    DAYS.map((day, i) => [
      day,
      {
        day,
        data: results[i]?.data ?? [],
        total: results[i]?.data?.length ?? 0,
      },
    ])
  );
}

export async function getScheduleDay(day: Day): Promise<{ day: string; data: unknown[]; total: number }> {
  const raw = (await jikanGet("/schedules", { filter: day, limit: 25 }, 300)) as JikanScheduleRaw;
  return {
    day,
    data: raw?.data ?? [],
    total: raw?.data?.length ?? 0,
  };
}

// ── Anime lists ───────────────────────────────────────────────────────────────

function normalizeAnime(item: Record<string, unknown>): Record<string, unknown> {
  const images = item.images as Record<string, Record<string, string>> | undefined;
  const trailer = item.trailer as Record<string, Record<string, string>> | undefined;
  const genres = (item.genres as { name: string }[] | undefined) ?? [];
  const studios = (item.studios as { name: string }[] | undefined) ?? [];
  const broadcast = item.broadcast as Record<string, string> | undefined;

  return {
    id: item.mal_id,
    title: item.title,
    title_english: item.title_english ?? null,
    image: images?.jpg?.large_image_url ?? images?.jpg?.image_url ?? null,
    banner: trailer?.images?.maximum_image_url ?? null,
    score: item.score ?? null,
    popularity: item.popularity ?? null,
    episodes: item.episodes ?? null,
    status: item.status ?? null,
    genres: genres.map((g) => g.name),
    synopsis: item.synopsis ?? null,
    year: item.year ?? null,
    season: item.season ?? null,
    format: item.type ?? null,
    source: "jikan",
    studios: studios.map((s) => s.name),
    broadcast_day: broadcast?.day ?? null,
    broadcast_time: broadcast?.time ?? null,
    duration: item.duration ?? null,
    rating: item.rating ?? null,
  };
}

type JikanListRaw = { data: Record<string, unknown>[]; pagination: unknown };

export async function getTrendingAnime(page = 1) {
  const raw = (await jikanGet("/top/anime", { page, filter: "bypopularity" }, 600)) as JikanListRaw;
  return { data: raw.data.map(normalizeAnime), pagination: raw.pagination };
}

export async function getAiringAnime(page = 1) {
  const raw = (await jikanGet("/top/anime", { page, filter: "airing" }, 300)) as JikanListRaw;
  return { data: raw.data.map(normalizeAnime), pagination: raw.pagination };
}

export async function getTopRatedAnime(page = 1) {
  const raw = (await jikanGet("/top/anime", { page }, 3600)) as JikanListRaw;
  return { data: raw.data.map(normalizeAnime), pagination: raw.pagination };
}

export async function getUpcomingAnime(page = 1) {
  const raw = (await jikanGet("/top/anime", { page, filter: "upcoming" }, 3600)) as JikanListRaw;
  return { data: raw.data.map(normalizeAnime), pagination: raw.pagination };
}

export async function getAnimeDetail(id: number) {
  const raw = (await jikanGet(`/anime/${id}/full`, {}, 3600)) as { data: Record<string, unknown> };
  return normalizeAnime(raw.data);
}

export async function getCurrentSeason(page = 1) {
  const raw = (await jikanGet("/seasons/now", { page }, 600)) as JikanListRaw;
  return { data: raw.data.map(normalizeAnime), pagination: raw.pagination };
}

export async function searchAnime(q: string, page = 1, status?: string, genres?: string) {
  const params: Record<string, string | number> = { q, page };
  if (status) params.status = status;
  if (genres) params.genres = genres;
  const raw = (await jikanGet("/anime", params, 60)) as JikanListRaw;
  return { data: raw.data.map(normalizeAnime), pagination: raw.pagination };
}

export async function getGenres() {
  const raw = (await jikanGet("/genres/anime", {}, 86400)) as {
    data: { mal_id: number; name: string; count: number }[];
  };
  return { data: raw.data };
}
