import { Link, useLocation } from "wouter";
import { Search, Tv } from "lucide-react";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [location] = useLocation();

  const links = [
    { href: "/", label: "Home" },
    { href: "/schedule", label: "Schedule" },
    { href: "/browse", label: "Browse" },
    { href: "/seasonal", label: "Seasonal" },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-[0_0_15px_rgba(109,40,217,0.5)] group-hover:shadow-[0_0_25px_rgba(109,40,217,0.7)] transition-shadow">
              <Tv className="w-5 h-5 text-white" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight">Anibinge</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-1">
            {links.map((link) => (
              <Link 
                key={link.href} 
                href={link.href}
                className={cn(
                  "px-4 py-2 rounded-md text-sm font-medium transition-colors hover:text-foreground",
                  location === link.href ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/50"
                )}
                data-testid={`nav-link-${link.label.toLowerCase()}`}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>

        <div className="flex items-center">
          <Link 
            href="/browse" 
            className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-secondary/50 border border-border/50 text-muted-foreground text-sm hover:bg-secondary hover:text-foreground transition-colors"
            data-testid="nav-search-button"
          >
            <Search className="w-4 h-4" />
            <span className="hidden sm:inline-block">Search anime...</span>
          </Link>
        </div>
      </div>
    </nav>
  );
}
