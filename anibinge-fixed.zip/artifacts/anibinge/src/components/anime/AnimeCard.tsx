import { Link } from "wouter";
import { Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import type { AnimeSummary, ScheduleItem } from "@workspace/api-client-react";

type CardProps = {
  anime: AnimeSummary | ScheduleItem;
  layout?: "grid" | "list";
  showTime?: boolean;
};

export function AnimeCard({ anime, layout = "grid", showTime = false }: CardProps) {
  const title = anime.title_english || anime.title;
  const image = 'image' in anime ? anime.image : anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url;
  const score = anime.score;
  const status = anime.status;
  
  const genres = ('genres' in anime && anime.genres && typeof anime.genres[0] === 'string') 
    ? (anime.genres as string[]) 
    : ('genres' in anime && anime.genres) 
      ? (anime.genres as {name: string}[]).map(g => g.name)
      : [];

  const time = showTime && 'broadcast' in anime && anime.broadcast?.time ? anime.broadcast.time : null;

  return (
    <Link href={`/anime/${anime.id || anime.mal_id}`}>
      <motion.div 
        whileHover={{ y: -4 }}
        className="group relative flex flex-col h-full rounded-lg bg-card border border-card-border overflow-hidden hover:border-primary/50 hover:shadow-[0_0_20px_rgba(109,40,217,0.15)] transition-all duration-300 cursor-pointer"
        data-testid={`anime-card-${anime.id || anime.mal_id}`}
      >
        <div className="relative aspect-[2/3] w-full overflow-hidden bg-muted">
          {image ? (
            <img 
              src={image} 
              alt={title} 
              className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-500 ease-out"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">No Image</div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-80" />
          
          <div className="absolute top-2 right-2 flex flex-col gap-1 items-end">
            {score ? (
              <Badge variant="secondary" className="bg-background/80 backdrop-blur-md border-border gap-1 font-bold">
                <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                {score.toFixed(1)}
              </Badge>
            ) : null}
            {time && (
              <Badge variant="glow" className="bg-primary/90 backdrop-blur-md border-transparent text-xs">
                {time}
              </Badge>
            )}
          </div>
          
          {status === "Currently Airing" && !showTime && (
            <div className="absolute top-2 left-2">
              <Badge variant="destructive" className="bg-red-500/90 hover:bg-red-500/90 text-[10px] uppercase tracking-wider">Airing</Badge>
            </div>
          )}
        </div>
        
        <div className="p-3 flex flex-col flex-1 gap-2">
          <h3 className="font-display font-semibold text-sm line-clamp-2 leading-tight group-hover:text-primary transition-colors">
            {title}
          </h3>
          <div className="flex flex-wrap gap-1 mt-auto pt-2">
            {genres.slice(0, 3).map((g, i) => (
              <span key={i} className="text-[10px] px-1.5 py-0.5 rounded-sm bg-secondary/80 text-secondary-foreground whitespace-nowrap">
                {g}
              </span>
            ))}
          </div>
        </div>
      </motion.div>
    </Link>
  );
}

export function AnimeCardSkeleton() {
  return (
    <div className="flex flex-col h-full rounded-lg bg-card border border-card-border overflow-hidden">
      <Skeleton className="aspect-[2/3] w-full rounded-none" />
      <div className="p-3 flex flex-col gap-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-2/3" />
        <div className="flex gap-1 mt-2">
          <Skeleton className="h-4 w-12" />
          <Skeleton className="h-4 w-16" />
        </div>
      </div>
    </div>
  );
}
