import React, { useCallback, useEffect, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { AnimeCard, AnimeCardSkeleton } from "./AnimeCard";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import type { AnimeSummary } from "@workspace/api-client-react";

interface AnimeCarouselProps {
  title: string;
  items: AnimeSummary[] | undefined;
  isLoading: boolean;
  viewAllLink?: string;
}

export function AnimeCarousel({ title, items, isLoading, viewAllLink }: AnimeCarouselProps) {
  const [emblaRef, emblaApi] = useEmblaCarousel({ 
    align: "start",
    containScroll: "trimSnaps",
    dragFree: true
  });
  
  const [prevBtnDisabled, setPrevBtnDisabled] = useState(true);
  const [nextBtnDisabled, setNextBtnDisabled] = useState(true);

  const scrollPrev = useCallback(() => emblaApi && emblaApi.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi && emblaApi.scrollNext(), [emblaApi]);

  const onSelect = useCallback((emblaApi: any) => {
    setPrevBtnDisabled(!emblaApi.canScrollPrev());
    setNextBtnDisabled(!emblaApi.canScrollNext());
  }, []);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect(emblaApi);
    emblaApi.on("reInit", onSelect);
    emblaApi.on("select", onSelect);
  }, [emblaApi, onSelect]);

  return (
    <div className="py-6">
      <div className="flex items-end justify-between mb-4 px-4 md:px-8">
        <div>
          <h2 className="text-2xl font-display font-bold text-foreground tracking-tight">{title}</h2>
        </div>
        <div className="flex items-center gap-2">
          {viewAllLink && (
            <Link href={viewAllLink} className="text-sm font-medium text-muted-foreground hover:text-primary mr-2 transition-colors">
              View All
            </Link>
          )}
          <Button 
            variant="outline" 
            size="icon" 
            className="w-8 h-8 rounded-full bg-background" 
            onClick={scrollPrev} 
            disabled={prevBtnDisabled}
            data-testid={`carousel-prev-${title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="w-8 h-8 rounded-full bg-background" 
            onClick={scrollNext} 
            disabled={nextBtnDisabled}
            data-testid={`carousel-next-${title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="overflow-hidden px-4 md:px-8" ref={emblaRef}>
        <div className="flex -ml-4">
          {isLoading ? (
            Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="pl-4 min-w-[140px] md:min-w-[180px] lg:min-w-[220px] flex-[0_0_auto]">
                <AnimeCardSkeleton />
              </div>
            ))
          ) : items && items.length > 0 ? (
            items.map((anime) => (
              <div key={anime.id} className="pl-4 min-w-[140px] md:min-w-[180px] lg:min-w-[220px] flex-[0_0_auto]">
                <AnimeCard anime={anime} />
              </div>
            ))
          ) : (
            <div className="pl-4 w-full text-muted-foreground text-sm">No anime found.</div>
          )}
        </div>
      </div>
    </div>
  );
}
