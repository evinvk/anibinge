import { useGetCurrentSeason, getGetCurrentSeasonQueryKey } from "@workspace/api-client-react";
import { AnimeCard, AnimeCardSkeleton } from "@/components/anime/AnimeCard";
import { motion } from "framer-motion";
import { Tv } from "lucide-react";

export default function Seasonal() {
  const { data, isLoading } = useGetCurrentSeason(
    { page: 1 },
    { query: { queryKey: getGetCurrentSeasonQueryKey({ page: 1 }) } }
  );

  return (
    <div className="container mx-auto px-4 md:px-8 py-8">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 rounded-xl bg-accent/20 text-accent border border-accent/30">
          <Tv className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold">Current Season</h1>
          <p className="text-muted-foreground text-sm mt-1">What's airing right now.</p>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {Array.from({length: 12}).map((_, j) => <AnimeCardSkeleton key={j} />)}
        </div>
      ) : data?.data ? (
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={{ visible: { transition: { staggerChildren: 0.05 } } }}
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6"
        >
          {data.data.map((anime) => (
            <motion.div
              key={anime.id}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 }
              }}
            >
              <AnimeCard anime={anime} />
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <div className="text-center py-20 text-muted-foreground">No seasonal data found.</div>
      )}
    </div>
  );
}
