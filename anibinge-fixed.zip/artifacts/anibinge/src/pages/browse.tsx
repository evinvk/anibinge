import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useSearchAnime, getSearchAnimeQueryKey, useGetGenres, getGetGenresQueryKey, SearchAnimeStatus } from "@workspace/api-client-react";
import { Search } from "lucide-react";
import { AnimeCard, AnimeCardSkeleton } from "@/components/anime/AnimeCard";
import { Button } from "@/components/ui/button";

const searchSchema = z.object({
  q: z.string().optional(),
  status: z.enum(["", "airing", "complete", "upcoming"]).optional(),
  genres: z.string().optional(),
});

type SearchFormValues = z.infer<typeof searchSchema>;

export default function Browse() {
  const [searchParams, setSearchParams] = useState<SearchFormValues>({ q: "" });
  const [page, setPage] = useState(1);
  const [allResults, setAllResults] = useState<any[]>([]);
  const [lastQueryKey, setLastQueryKey] = useState("");

  const { register, handleSubmit } = useForm<SearchFormValues>({
    resolver: zodResolver(searchSchema),
    defaultValues: {
      q: "",
      status: "",
      genres: "",
    }
  });

  const { data: genresData } = useGetGenres({
    query: { queryKey: getGetGenresQueryKey() }
  });

  const activeParams: any = { page };
  if (searchParams.q) activeParams.q = searchParams.q;
  if (searchParams.status) activeParams.status = searchParams.status as SearchAnimeStatus;
  if (searchParams.genres) activeParams.genres = searchParams.genres;

  const currentQueryKey = JSON.stringify(activeParams);
  
  const { data, isLoading, isFetching } = useSearchAnime(activeParams, {
    query: {
      queryKey: getSearchAnimeQueryKey(activeParams),
    }
  });

  if (data?.data && currentQueryKey !== lastQueryKey) {
    if (page === 1) {
      setAllResults(data.data);
    } else {
      setAllResults(prev => [...prev, ...data.data]);
    }
    setLastQueryKey(currentQueryKey);
  }

  const onSubmit = (values: SearchFormValues) => {
    setSearchParams(values);
    setPage(1);
  };

  const hasNextPage = data?.pagination?.has_next_page;

  return (
    <div className="container mx-auto px-4 md:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold mb-6">Browse Anime</h1>
        
        <form onSubmit={handleSubmit(onSubmit)} className="bg-card border border-card-border p-4 rounded-xl space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input
                {...register("q")}
                placeholder="Search by title..."
                className="w-full pl-9 pr-4 py-2 bg-background border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              />
            </div>
            
            <select
              {...register("status")}
              className="w-full md:w-48 px-4 py-2 bg-background border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="">Any Status</option>
              <option value="airing">Airing</option>
              <option value="complete">Completed</option>
              <option value="upcoming">Upcoming</option>
            </select>

            <select
              {...register("genres")}
              className="w-full md:w-48 px-4 py-2 bg-background border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="">Any Genre</option>
              {genresData?.data?.map(g => (
                <option key={g.mal_id} value={g.mal_id.toString()}>{g.name}</option>
              ))}
            </select>
            
            <Button type="submit" className="w-full md:w-auto">
              Search
            </Button>
          </div>
        </form>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
        {allResults.map((anime, idx) => (
          <AnimeCard key={`${anime.id}-${idx}`} anime={anime} />
        ))}
        {(isLoading || isFetching) && Array.from({length: 12}).map((_, i) => <AnimeCardSkeleton key={`skel-${i}`} />)}
      </div>

      {!isLoading && allResults.length === 0 && (
        <div className="text-center py-20 text-muted-foreground">
          No anime found matching your criteria.
        </div>
      )}

      {hasNextPage && !isLoading && !isFetching && (
        <div className="mt-12 flex justify-center">
          <Button 
            variant="outline" 
            size="lg" 
            onClick={() => setPage(p => p + 1)}
            className="px-12 rounded-full"
          >
            Load More
          </Button>
        </div>
      )}
    </div>
  );
}
