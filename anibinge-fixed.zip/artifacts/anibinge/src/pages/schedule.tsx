import { useGetWeeklySchedule, getGetWeeklyScheduleQueryKey } from "@workspace/api-client-react";
import { AnimeCard, AnimeCardSkeleton } from "@/components/anime/AnimeCard";
import { format } from "date-fns";
import { motion } from "framer-motion";
import { Calendar } from "lucide-react";

const DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"] as const;

function formatLocalTime(timeStr?: string | null) {
  if (!timeStr) return "Time TBD";
  try {
    const local = new Date(`1970-01-01T${timeStr}:00`);
    if (isNaN(local.getTime())) return timeStr;
    return format(local, "h:mm a");
  } catch (e) {
    return timeStr;
  }
}

export default function Schedule() {
  const { data: schedule, isLoading } = useGetWeeklySchedule({
    query: { queryKey: getGetWeeklyScheduleQueryKey() }
  });

  const todayIndex = new Date().getDay();
  const todayName = DAYS[todayIndex === 0 ? 6 : todayIndex - 1];
  
  const sortedDays = [
    todayName,
    ...DAYS.filter(d => d !== todayName)
  ];

  return (
    <div className="container mx-auto px-4 md:px-8 py-8">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 rounded-xl bg-primary/20 text-primary border border-primary/30">
          <Calendar className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold">Weekly Schedule</h1>
          <p className="text-muted-foreground text-sm mt-1">Track airing times in your local timezone.</p>
        </div>
      </div>

      <div className="space-y-16">
        {isLoading ? (
          <div className="space-y-8">
            {[1, 2, 3].map(i => (
              <div key={i}>
                <div className="h-8 w-48 bg-muted animate-pulse rounded mb-4" />
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                  {Array.from({length: 6}).map((_, j) => <AnimeCardSkeleton key={j} />)}
                </div>
              </div>
            ))}
          </div>
        ) : schedule ? (
          sortedDays.map((day, idx) => {
            const dayData = schedule[day];
            if (!dayData || !dayData.data || dayData.data.length === 0) return null;
            
            const isToday = day === todayName;

            return (
              <div key={day} className="relative">
                <div className="flex items-center gap-4 mb-6 sticky top-[64px] z-20 bg-background/95 backdrop-blur-md py-4 border-b border-border/50">
                  <h2 className="text-2xl font-display font-semibold capitalize text-foreground">
                    {day}
                  </h2>
                  {isToday && (
                    <span className="px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-full bg-primary text-primary-foreground shadow-[0_0_15px_rgba(109,40,217,0.6)] animate-[pulse_2s_ease-in-out_infinite]">
                      Today
                    </span>
                  )}
                  <span className="text-sm text-muted-foreground ml-auto">
                    {dayData.total} Shows
                  </span>
                </div>
                
                <motion.div 
                  initial="hidden"
                  animate="visible"
                  variants={{
                    visible: { transition: { staggerChildren: 0.05 } }
                  }}
                  className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-4 md:gap-6"
                >
                  {dayData.data.map((anime, animeIdx) => {
                    const timeFormatted = formatLocalTime(anime.broadcast?.time);
                    const animeWithLocalTime = {
                      ...anime,
                      broadcast: {
                        ...anime.broadcast,
                        time: timeFormatted
                      }
                    };

                    return (
                      <motion.div
                        key={`${day}-${anime.mal_id}-${animeIdx}`}
                        variants={{
                          hidden: { opacity: 0, y: 20 },
                          visible: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
                        }}
                      >
                        <AnimeCard anime={animeWithLocalTime} showTime={true} />
                      </motion.div>
                    );
                  })}
                </motion.div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-20 text-muted-foreground">
            Failed to load schedule.
          </div>
        )}
      </div>
    </div>
  );
}
