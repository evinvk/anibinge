import { 
  useGetCurrentlyAiring, 
  useGetTrendingAnime, 
  useGetTopRated, 
  useGetUpcoming,
  getGetCurrentlyAiringQueryKey,
  getGetTrendingAnimeQueryKey,
  getGetTopRatedQueryKey,
  getGetUpcomingQueryKey
} from "@workspace/api-client-react";
import { AnimeCarousel } from "@/components/anime/AnimeCarousel";
import { Play } from "lucide-react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

function HeroSkeleton() {
  return <Skeleton className="w-full h-[60vh] md:h-[70vh] rounded-none" />;
}

export default function Home() {
  const { data: trending, isLoading: loadingTrending } = useGetTrendingAnime(
    { page: 1 }, 
    { query: { queryKey: getGetTrendingAnimeQueryKey({ page: 1 }) } }
  );
  
  const { data: airing, isLoading: loadingAiring } = useGetCurrentlyAiring(
    { page: 1 },
    { query: { queryKey: getGetCurrentlyAiringQueryKey({ page: 1 }) } }
  );

  const { data: topRated, isLoading: loadingTopRated } = useGetTopRated(
    { page: 1 },
    { query: { queryKey: getGetTopRatedQueryKey({ page: 1 }) } }
  );

  const { data: upcoming, isLoading: loadingUpcoming } = useGetUpcoming(
    { page: 1 },
    { query: { queryKey: getGetUpcomingQueryKey({ page: 1 }) } }
  );

  const featured = trending?.data?.[0] || airing?.data?.[0];
  const featuredImage = featured?.banner || featured?.image;

  return (
    <div className="pb-12">
      {/* Hero Section */}
      {!featured && (loadingTrending || loadingAiring) ? (
        <HeroSkeleton />
      ) : featured ? (
        <div className="relative w-full h-[60vh] md:h-[70vh] flex items-center mb-8 bg-muted">
          <div className="absolute inset-0 overflow-hidden">
            {featuredImage && (
              <img 
                src={featuredImage} 
                alt={featured.title_english || featured.title} 
                className="w-full h-full object-cover object-center opacity-40 scale-105"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/40 to-transparent" />
          </div>
          
          <div className="container mx-auto px-4 md:px-8 relative z-10">
            <div className="max-w-2xl">
              <div className="flex gap-2 mb-4">
                <span className="px-2 py-1 rounded bg-primary/20 text-primary-foreground text-xs font-bold border border-primary/30 uppercase tracking-wider backdrop-blur-sm">
                  {featured.status === "Currently Airing" ? "Airing Now" : "Featured"}
                </span>
                {featured.score && (
                  <span className="px-2 py-1 rounded bg-secondary/80 text-secondary-foreground text-xs font-bold backdrop-blur-sm border border-secondary">
                    Score {featured.score}
                  </span>
                )}
              </div>
              <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-4 leading-tight drop-shadow-lg">
                {featured.title_english || featured.title}
              </h1>
              {featured.synopsis && (
                <p className="text-base md:text-lg text-muted-foreground mb-8 line-clamp-3 md:line-clamp-4 max-w-xl drop-shadow-md">
                  {featured.synopsis}
                </p>
              )}
              <div className="flex flex-wrap items-center gap-4">
                <Link href={`/anime/${featured.id}`} className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 h-11 px-8 bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(109,40,217,0.4)] hover:shadow-[0_0_30px_rgba(109,40,217,0.6)]">
                  <Play className="w-4 h-4 mr-2 fill-current" />
                  View Details
                </Link>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="w-full h-[30vh] flex items-center justify-center bg-muted/20">
          <p className="text-muted-foreground">Unable to load featured anime.</p>
        </div>
      )}

      <div className="container mx-auto space-y-4">
        <AnimeCarousel 
          title="Trending Now" 
          items={trending?.data} 
          isLoading={loadingTrending} 
        />
        <AnimeCarousel 
          title="Currently Airing" 
          items={airing?.data} 
          isLoading={loadingAiring} 
        />
        <AnimeCarousel 
          title="Top Rated" 
          items={topRated?.data} 
          isLoading={loadingTopRated} 
        />
        <AnimeCarousel 
          title="Upcoming" 
          items={upcoming?.data} 
          isLoading={loadingUpcoming} 
        />
      </div>
    </div>
  );
}
