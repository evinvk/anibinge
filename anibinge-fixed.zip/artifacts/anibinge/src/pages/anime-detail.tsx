import { useParams } from "wouter";
import { useGetAnimeDetail, getGetAnimeDetailQueryKey } from "@workspace/api-client-react";
import { Star, TrendingUp, Hash, PlayCircle, Clock, Calendar, Tv, Users } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function AnimeDetail() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);

  const { data: anime, isLoading, error } = useGetAnimeDetail(id, {
    query: {
      enabled: !!id,
      queryKey: getGetAnimeDetailQueryKey(id)
    }
  });

  if (isLoading) {
    return (
      <div className="animate-pulse">
        <div className="w-full h-[40vh] bg-muted/50" />
        <div className="container mx-auto px-4 md:px-8 -mt-24 relative z-10">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="w-48 md:w-64 flex-shrink-0">
              <div className="aspect-[2/3] bg-muted rounded-lg border-4 border-background" />
            </div>
            <div className="flex-1 mt-4 md:mt-24 space-y-4">
              <div className="h-10 bg-muted rounded w-3/4" />
              <div className="h-4 bg-muted rounded w-1/4" />
              <div className="h-32 bg-muted rounded w-full mt-8" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !anime) {
    return (
      <div className="container mx-auto px-4 py-20 text-center text-muted-foreground">
        Failed to load anime details.
      </div>
    );
  }

  const title = anime.title_english || anime.title;
  const image = anime.image;
  const banner = anime.banner || image;

  return (
    <div className="pb-20">
      {/* Banner */}
      <div className="relative w-full h-[40vh] md:h-[50vh] bg-muted overflow-hidden">
        {banner && (
          <img 
            src={banner} 
            alt={title} 
            className="w-full h-full object-cover object-center opacity-40 blur-sm scale-110"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      </div>

      <div className="container mx-auto px-4 md:px-8 -mt-32 md:-mt-48 relative z-10">
        <div className="flex flex-col md:flex-row gap-6 md:gap-10">
          
          {/* Left Column: Poster */}
          <div className="w-48 md:w-64 flex-shrink-0 mx-auto md:mx-0">
            <div className="aspect-[2/3] rounded-lg border-4 border-background shadow-2xl overflow-hidden bg-muted">
              {image ? (
                <img src={image} alt={title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">No Image</div>
              )}
            </div>
            
            {/* Quick Stats below poster */}
            <div className="mt-6 space-y-3 bg-card rounded-lg p-4 border border-card-border">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground flex items-center gap-1.5"><Tv className="w-4 h-4"/> Format</span>
                <span className="font-medium text-foreground">{anime.format || "Unknown"}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground flex items-center gap-1.5"><PlayCircle className="w-4 h-4"/> Episodes</span>
                <span className="font-medium text-foreground">{anime.episodes || "?"}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground flex items-center gap-1.5"><Clock className="w-4 h-4"/> Duration</span>
                <span className="font-medium text-foreground">{anime.duration || "Unknown"}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground flex items-center gap-1.5"><Calendar className="w-4 h-4"/> Season</span>
                <span className="font-medium text-foreground capitalize">{anime.season} {anime.year}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground flex items-center gap-1.5"><Users className="w-4 h-4"/> Studio</span>
                <span className="font-medium text-foreground truncate max-w-[100px] text-right" title={anime.studios?.join(", ")}>
                  {anime.studios?.[0] || "Unknown"}
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Details */}
          <div className="flex-1 mt-4 md:mt-16">
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge variant={anime.status === "Currently Airing" ? "glow" : "secondary"}>
                {anime.status}
              </Badge>
              {anime.rating && <Badge variant="outline">{anime.rating}</Badge>}
              {anime.broadcast_day && anime.broadcast_time && (
                <Badge variant="outline" className="border-primary/30 text-primary">
                  Airs: {anime.broadcast_day}s at {anime.broadcast_time}
                </Badge>
              )}
            </div>

            <h1 className="text-3xl md:text-5xl font-display font-bold text-foreground mb-2 leading-tight">
              {title}
            </h1>
            
            {anime.title_japanese && (
              <h2 className="text-lg md:text-xl text-muted-foreground mb-6 font-medium">
                {anime.title_japanese}
              </h2>
            )}

            {/* Stats Row */}
            <div className="flex flex-wrap items-center gap-6 mb-8 p-4 rounded-xl bg-card/50 border border-card-border/50">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-yellow-500/10 flex items-center justify-center">
                  <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                </div>
                <div>
                  <div className="text-xl font-bold">{anime.score || "N/A"}</div>
                  <div className="text-xs text-muted-foreground">{anime.scored_by?.toLocaleString()} users</div>
                </div>
              </div>
              
              <div className="w-px h-10 bg-border hidden sm:block" />
              
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Hash className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <div className="text-xl font-bold">{anime.rank ? `#${anime.rank}` : "N/A"}</div>
                  <div className="text-xs text-muted-foreground">Ranked</div>
                </div>
              </div>

              <div className="w-px h-10 bg-border hidden sm:block" />
              
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-emerald-500" />
                </div>
                <div>
                  <div className="text-xl font-bold">{anime.popularity ? `#${anime.popularity}` : "N/A"}</div>
                  <div className="text-xs text-muted-foreground">Popularity</div>
                </div>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-xl font-display font-semibold mb-3">Synopsis</h3>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {anime.synopsis || "No synopsis available."}
              </p>
            </div>

            <div>
              <h3 className="text-xl font-display font-semibold mb-3">Genres</h3>
              <div className="flex flex-wrap gap-2">
                {anime.genres?.map(genre => (
                  <Badge key={genre} variant="secondary" className="px-3 py-1 bg-secondary hover:bg-secondary/80">
                    {genre}
                  </Badge>
                ))}
              </div>
            </div>

            {anime.trailer_url && (
              <div className="mt-8">
                <a 
                  href={anime.trailer_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-11 px-8 shadow-[0_0_20px_rgba(109,40,217,0.3)]"
                >
                  <PlayCircle className="w-5 h-5 mr-2" />
                  Watch Trailer
                </a>
              </div>
            )}
            
          </div>
        </div>
      </div>
    </div>
  );
}
