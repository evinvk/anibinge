import asyncio
import logging

from fastapi import APIRouter, Query

from app.services import jikan_client

logger = logging.getLogger("anibinge")

router = APIRouter(prefix="/api/v1/schedule", tags=["schedule"])

VALID_DAYS = [
    "monday", "tuesday", "wednesday", "thursday",
    "friday", "saturday", "sunday",
]

# Jikan enforces ~3 req/sec. Firing all 7 days at once with a plain
# asyncio.gather trips that limit on a cold cache (first load, or once
# the 5-min TTL expires) and raises, which used to 500 the *entire*
# weekly response just because one day's request got rate-limited.
# A semaphore throttles concurrency, and each day is fetched
# defensively so a single upstream failure doesn't take down the rest
# of the week.
_SCHEDULE_CONCURRENCY = asyncio.Semaphore(2)


async def _get_day_safe(day: str) -> dict:
    async with _SCHEDULE_CONCURRENCY:
        try:
            return await jikan_client.get_schedule(day)
        except Exception:
            logger.exception("Schedule fetch failed for %s", day)
            return {"data": []}


@router.get("/weekly")
async def weekly_schedule():
    """Fetch all 7 days, throttled so we don't trip Jikan's rate limit."""
    results = await asyncio.gather(*[_get_day_safe(day) for day in VALID_DAYS])
    return dict(zip(VALID_DAYS, results))


@router.get("/{day}")
async def day_schedule(day: str, tz_offset_minutes: int = Query(0, description="Client UTC offset for local-time display")):
    day = day.lower()
    if day not in VALID_DAYS:
        return {"error": "invalid day", "valid_days": sorted(VALID_DAYS)}
    return await jikan_client.get_schedule(day)
