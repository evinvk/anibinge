"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { AnimeCard, AnimeCardSkeleton, AnimeGrid } from "@/components/anime-card";
import type { AnimeSummary } from "@/lib/api";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

function normalizeJikan(item: any): AnimeSummary {
  return {
    id: item.mal_id,
    source: "jikan",
    title: item.title,
    title_english: item.title_english,
    image: item.images?.jpg?.large_image_url ?? null,
    banner: item.trailer?.images?.maximum_image_url ?? null,
    score: item.score ?? null,
    popularity: item.popularity ?? null,
    episodes: item.episodes ?? null,
    status: item.status ?? null,
    genres: item.genres?.map((g: any) => g.name) ?? [],
    synopsis: item.synopsis ?? null,
    year: item.year ?? null,
    season: item.season ?? null,
    format: item.type ?? null,
  };
}

interface InfiniteJikanGridProps {
  /** API path, without page query param, e.g. "/api/v1/anime/upcoming" */
  path: string;
  initialData: any; // raw Jikan response: { data: [...], pagination: { has_next_page } }
}

export function InfiniteJikanGrid({ path, initialData }: InfiniteJikanGridProps) {
  const initialItems = (initialData?.data ?? []).map(normalizeJikan);
  const initialHasMore = initialData?.pagination?.has_next_page ?? initialItems.length > 0;

  const [items, setItems] = useState<AnimeSummary[]>(initialItems);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(initialHasMore);
  const [isVisible, setIsVisible] = useState(false);
  const sentinelRef = useRef<HTMLDivElement>(null);

  // Reset when the underlying data source changes (e.g. path swap)
  useEffect(() => {
    setItems(initialItems);
    setPage(1);
    setHasMore(initialHasMore);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, initialData]);

  const loadMore = useCallback(async () => {
    setLoading(true);
    try {
      const nextPage = page + 1;
      const res = await fetch(`${API_BASE}${path}?page=${nextPage}`);
      if (!res.ok) throw new Error(`Request failed: ${res.status}`);
      const json = await res.json();
      const newItems: AnimeSummary[] = (json.data ?? []).map(normalizeJikan);

      if (newItems.length === 0) {
        setHasMore(false);
      } else {
        setItems((prev) => [...prev, ...newItems]);
        setPage(nextPage);
        setHasMore(json.pagination?.has_next_page ?? true);
      }
    } catch (err) {
      console.error("Failed to load more anime:", err);
      setHasMore(false);
    } finally {
      setLoading(false);
    }
  }, [page, path]);

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => setIsVisible(entries[0].isIntersecting),
      { rootMargin: "600px" }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible || loading || !hasMore) return;
    const timer = setTimeout(() => loadMore(), 400);
    return () => clearTimeout(timer);
  }, [isVisible, loading, hasMore, loadMore]);

  return (
    <>
      <AnimeGrid className="mt-8">
        {items.map((anime, i) => (
          <AnimeCard key={`${anime.id}-${i}`} anime={anime} />
        ))}
        {loading &&
          Array.from({ length: 6 }).map((_, i) => <AnimeCardSkeleton key={`skeleton-${i}`} />)}
      </AnimeGrid>

      <div ref={sentinelRef} className="h-1" />

      {!hasMore && items.length > 0 && (
        <p className="mt-10 text-center text-sm text-mist">
          You've reached the end — {items.length} titles loaded.
        </p>
      )}

      {items.length === 0 && !loading && (
        <div className="mt-16 text-center text-mist">
          Nothing to show here right now — check back soon.
        </div>
      )}
    </>
  );
}
