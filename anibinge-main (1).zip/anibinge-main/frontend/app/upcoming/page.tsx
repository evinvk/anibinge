import { Sparkles } from "lucide-react";
import { api } from "@/lib/api";
import { InfiniteJikanGrid } from "@/components/infinite-jikan-grid";

export const metadata = {
  title: "Upcoming Anime",
  description: "The most anticipated not-yet-aired anime, ranked by hype.",
};

export const revalidate = 3600;

export default async function UpcomingPage() {
  let data: any = { data: [] };
  let fetchFailed = false;

  try {
    data = await api.upcoming();
  } catch (err) {
    console.error("Upcoming anime fetch failed:", err);
    fetchFailed = true;
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="flex items-center gap-2">
        <Sparkles className="h-6 w-6 text-primary-400" />
        <h1 className="font-display text-3xl font-bold text-paper">Upcoming Anime</h1>
      </div>
      <p className="mt-1 text-mist">
        Not-yet-aired titles, ranked by anticipation. Looking for a specific season's lineup
        instead? Check the{" "}
        <a href="/seasonal?season=upcoming" className="text-primary-400 hover:text-primary-300">
          next season preview
        </a>
        .
      </p>

      {fetchFailed ? (
        <div className="mt-16 text-center text-mist">
          The anime database is temporarily unavailable. Please try again in a moment.
        </div>
      ) : (
        <InfiniteJikanGrid path="/api/v1/anime/upcoming" initialData={data} />
      )}
    </div>
  );
}
